// Quick Translate — inline translation.
//
// Returns the translated string; OpenClip delivers it per the user's General-tab
// preference (preview / paste / copy). Target language comes from the `targetLang`
// option (a picker in the action's config sheet; default "en").
//
// Backends, tried in order until one succeeds — ALL keyless, ALL auto-detect
// the source language:
//   1–2. Google gtx endpoint on both Google hosts (separate throttle buckets).
//   3.   Chrome dictionary endpoint (clients5.google.com) — separate infrastructure.
//   4.   LibreTranslate @ translate.disroot.org (Argos engine, source:"auto").
//   5.   SimplyTranslate @ simplytranslate.org (Google engine, from=auto).
//   6.   Lingva @ lingva.ml (official instance; down at authoring time but kept
//        as a free shot — fails fast if still dead).

// Keep selections bounded: percent-encoding inflates the query string and both
// backends have practical URL/request-size limits well below their char caps.
var MAX_SELECTION_CHARS = 4000;

// Browser-ish UA: endpoints apply different treatment per client signature
// (the gtx endpoint 429s non-browser UAs far more aggressively).
var BROWSER_UA =
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 ' +
  '(KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36';

// IMPORTANT: OpenClip's fetch polyfill response accessors are SYNCHRONOUS —
// `res.json()` / `res.text()` return values directly, not Promises (unlike
// browser/Node fetch). jsonOf() accepts either so the code works in both.
function jsonOf(res) {
  var v = res.json();
  return (v && typeof v.then === 'function') ? v : Promise.resolve(v);
}

// The classic gtx endpoint, tried on both Google hosts (separate throttle buckets).
// `redirectFor(detected)` (optional) returns a different language code to use
// when the detected source language makes the requested target pointless.
function translateViaGtx(host, text, targetLang, redirectFor) {
  var url =
    'https://' + host + '/translate_a/single' +
    '?client=gtx&sl=auto&dt=t' +
    '&tl=' + encodeURIComponent(targetLang) +
    '&q=' + encodeURIComponent(text);
  return openclip.fetch(url, { headers: { 'User-Agent': BROWSER_UA } }).then(function (res) {
    if (!res.ok) {
      throw new Error('gtx(' + host + ') HTTP ' + res.status +
        (res.status === 429 ? ' (rate limited)' : ''));
    }
    return jsonOf(res).then(function (data) {
      // data[0] is an array of segments: [[translated, original, …], …]
      if (!data || !Array.isArray(data[0])) {
        throw new Error('Unexpected gtx response shape');
      }
      // If the text is already in the target language, optionally translate to
      // another language instead — see resolveLanguages(). gtx reports the
      // detected source language in data[2].
      var detected = data[2];
      var redirected = redirectFor ? redirectFor(detected) : null;
      if (redirected && redirected !== targetLang) {
        return translateViaGtx(host, text, redirected);
      }
      var translated = data[0].map(function (seg) { return seg[0] || ''; }).join('');
      return translated;
    });
  });
}

// The Chrome dictionary endpoint: keyless, auto-detects, separate infrastructure
// from gtx. Shape: [["<translation>", "<detected src>"], …].
function translateViaDictChrome(text, targetLang) {
  var url =
    'https://clients5.google.com/translate_a/t' +
    '?client=dict-chrome-ex&sl=auto' +
    '&tl=' + encodeURIComponent(targetLang) +
    '&q=' + encodeURIComponent(text);
  return openclip.fetch(url, { headers: { 'User-Agent': BROWSER_UA } }).then(function (res) {
    if (!res.ok) {
      throw new Error('dict-chrome-ex HTTP ' + res.status);
    }
    return jsonOf(res).then(function (data) {
      // Accept [["t","src"],…] and ["t", …] shapes; join every segment string.
      var parts = (data || []).map(function (seg) {
        return Array.isArray(seg) ? String(seg[0] || '') : String(seg || '');
      });
      var translated = parts.join('');
      if (!translated.trim()) {
        throw new Error('dict-chrome-ex returned no translation');
      }
      return translated;
    });
  });
}

// Language-code mapping: the picker uses Microsoft-style codes; some backends
// differ. Anything unmapped passes through unchanged (failures just cascade).
function langFor(code, aliases) {
  return (aliases && aliases[code]) || code;
}
var LT_ALIASES      = { 'zh-Hans': 'zh', 'zh-Hant': 'zt' };
var LINGVA_ALIASES  = { 'zh-Hans': 'zh_HANS', 'zh-Hant': 'zh_HANT' };

// The target picker shows display names; backends need language codes.
// Anything not in the map (e.g. a legacy saved code like "sv") passes through.
var TARGET_CODES = {
  'English': 'en', 'Hindi': 'hi', 'Spanish': 'es', 'French': 'fr', 'German': 'de',
  'Japanese': 'ja', 'Chinese (Simplified)': 'zh-Hans', 'Chinese (Traditional)': 'zh-Hant',
  'Korean': 'ko', 'Portuguese': 'pt', 'Russian': 'ru', 'Arabic': 'ar', 'Italian': 'it',
  'Turkish': 'tr', 'Dutch': 'nl', 'Polish': 'pl', 'Swedish': 'sv', 'Danish': 'da',
  'Finnish': 'fi', 'Norwegian': 'no', 'Czech': 'cs', 'Greek': 'el', 'Hebrew': 'he',
  'Thai': 'th', 'Vietnamese': 'vi', 'Indonesian': 'id', 'Ukrainian': 'uk',
  'Bengali': 'bn', 'Tamil': 'ta', 'Telugu': 'te', 'Malayalam': 'ml', 'Urdu': 'ur',
  'Persian': 'fa', 'Punjabi': 'pa', 'Marathi': 'mr', 'Filipino': 'tl', 'Swahili': 'sw',
  'Romanian': 'ro', 'Gujarati': 'gu', 'Hungarian': 'hu', 'Malay': 'ms', 'Slovak': 'sk',
  'Bulgarian': 'bg', 'Serbian': 'sr', 'Burmese': 'my', 'Kannada': 'kn',
  'Kashmiri (Koshur)': 'ks'
};

// LibreTranslate (Argos engine) — keyless community instance, auto-detect via
// source:"auto". Shape: { detectedLanguage: {language, confidence}, translatedText }.
function translateViaLibreTranslate(text, targetLang) {
  return openclip.fetch('https://translate.disroot.org/translate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      q: text, source: 'auto',
      target: langFor(targetLang, LT_ALIASES), format: 'text'
    })
  }).then(function (res) {
    if (!res.ok) {
      throw new Error('LibreTranslate HTTP ' + res.status);
    }
    return jsonOf(res).then(function (data) {
      var t = data && data.translatedText;
      if (!t || !String(t).trim()) {
        throw new Error((data && data.error) || 'LibreTranslate returned no translation');
      }
      return String(t);
    });
  });
}

// SimplyTranslate — front-end with multi-engine support; google engine + from=auto.
// Shape: { translated_text: string, source_language: string, … }.
function translateViaSimplyTranslate(text, targetLang) {
  var url =
    'https://simplytranslate.org/api/translate/' +
    '?engine=google&from=auto' +
    '&to=' + encodeURIComponent(langFor(targetLang)) +
    '&text=' + encodeURIComponent(text);
  return openclip.fetch(url).then(function (res) {
    if (!res.ok) {
      throw new Error('SimplyTranslate HTTP ' + res.status);
    }
    return jsonOf(res).then(function (data) {
      var t = data && data.translated_text;
      if (!t || !String(t).trim()) {
        throw new Error((data && data.error) || 'SimplyTranslate returned no translation');
      }
      return String(t);
    });
  });
}

// Lingva — Google Translate proxy front-end; "auto" source detects. Official
// instance was erroring at authoring time; kept as a last-ditch free shot.
// Shape: { translation: string } or { error: string }.
function translateViaLingva(text, targetLang) {
  // Lingva's API takes the query in the path — double-encode so slashes and
  // spaces survive their own routing layer.
  var query = encodeURIComponent(encodeURIComponent(text));
  var url =
    'https://lingva.ml/api/v1/auto/' +
    encodeURIComponent(langFor(targetLang, LINGVA_ALIASES)) + '/' + query;
  return openclip.fetch(url, { headers: { 'User-Agent': BROWSER_UA } }).then(function (res) {
    if (!res.ok) {
      throw new Error('Lingva HTTP ' + res.status);
    }
    return jsonOf(res).then(function (data) {
      var t = data && data.translation;
      if (!t || !String(t).trim()) {
        throw new Error((data && data.error) || 'Lingva returned no translation');
      }
      return String(t);
    });
  });
}

// Backends in priority order. All return the translated string; all auto-detect
// the source language.
function buildBackends(redirectFor) {
  return [
    function (text, lang) { return translateViaGtx('translate.googleapis.com', text, lang, redirectFor); },
    function (text, lang) { return translateViaGtx('translate.google.com', text, lang, redirectFor); },
    translateViaDictChrome,
    translateViaLibreTranslate,
    translateViaSimplyTranslate,
    translateViaLingva
  ];
}

function codeFor(name) {
  return TARGET_CODES[name] || name;
}

// Picks the language for this click plus a redirect for "already in that
// language" (only gtx reports the detected source, so only gtx redirects).
//   - Click → primary; right-click/⇧-click with a Secondary Language → secondary.
//   - `alreadyTarget`: "Keep as is" never redirects; "Switch to the other
//     language" sends text already in the clicked language to the other one
//     (no-op when Secondary Language is None).
// Legacy values: "Translate to second language" and "Translate to English
// instead" both map to Switch (Keep as is when no Secondary Language).
function switchMode() {
  var mode = openclip.option('alreadyTarget');
  return mode === 'Switch to the other language' ||
    mode === 'Translate to second language' ||
    mode === 'Translate to English instead';
}

function resolveLanguages() {
  var targetLang = codeFor(openclip.option('targetLang') || 'English');
  var secondPicked = openclip.option('secondLang');
  var secondLang = (secondPicked && secondPicked !== 'None') ? codeFor(secondPicked) : null;
  if (secondLang === targetLang) secondLang = null;
  var swap = !!secondLang && switchMode();
  var lang = (secondLang && openclip.input.isSecondaryClick) ? secondLang : targetLang;
  var other = lang === targetLang ? secondLang : targetLang;
  return {
    lang: lang,
    redirectFor: function (detected) {
      return (swap && detected && detected === lang) ? other : null;
    }
  };
}

async function action() {
  var text = openclip.input.text.trim();
  if (!text) {
    openclip.toast('Nothing selected to translate', 'error');
    return;
  }
  if (text.length > MAX_SELECTION_CHARS) {
    openclip.toast('Selection too long (' + text.length + ' chars, max ' + MAX_SELECTION_CHARS + ')', 'error');
    return;
  }

  var resolved = resolveLanguages();
  var targetLang = resolved.lang;

  var translated = null;
  var failures = [];
  var backends = buildBackends(resolved.redirectFor);
  for (var i = 0; i < backends.length && !translated; i++) {
    try {
      translated = await backends[i](text, targetLang);
    } catch (err) {
      console.log('Backend ' + i + ' failed:', String(err));
      failures.push(String(err));
    }
  }

  if (!translated || !translated.trim()) {
    openclip.toast(
      'Translation failed: ' +
      (failures.length ? failures.join(' | ') : 'empty translation'),
      'error', { keepVisible: true });
    return;
  }

  // Return the string: OpenClip resolves it as a `.text` result delivered per
  // the user's General-tab preference (preview / paste / copy), with defaults
  // of primary-click paste and secondary-click copy.
  return translated;
}

